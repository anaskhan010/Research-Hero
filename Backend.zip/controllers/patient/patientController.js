var patientModel = require("../../models/patient/patientModel.js");
var crypto = require("crypto-js");
var authMiddleware = require("../../middleware/authMiddleware.js");

var createPatient = async function (req, res) {
  var _req$body = req.body,
    first_name = _req$body.first_name,
    last_name = _req$body.last_name,
    email = _req$body.email,
    password = _req$body.password,
    status = _req$body.status,
    gender = _req$body.gender,
    address = _req$body.address,
    contact_number = _req$body.contact_number,
    data_of_birth = _req$body.data_of_birth,
    stipend = _req$body.stipend,
    study_enrolled = _req$body.study_enrolled,
    notification = _req$body.notification,
    note = _req$body.note;

  var hashPassword = crypto.SHA256(password).toString();
  try {
    var result = await patientModel.createPatient(
      first_name,
      last_name,
      email,
      hashPassword,
      status,
      gender,
      address,
      contact_number,
      data_of_birth,
      stipend,
      study_enrolled,
      notification,
      note
    );
    res.status(200).json({
      status: true,
      message: "Patient Created Successfully",
      result: result,
    });
  } catch (error) {
    res
      .status(500)
      .json({ status: false, message: "Internal Server Error", error: error });
  }
};

// signin patient
var signinPatient = async function (req, res) {
  var email = req.body.email,
    password = req.body.password;

  try {
    var patient = await patientModel.signinPatient(email);
    if (!patient) {
      return res
        .status(400)
        .json({ status: false, message: "Patient Not Found" });
    }

    if (!isMatch) {
      return res
        .status(400)
        .json({ status: false, message: "Invalid Email or Password" });
    } else {
      var token = authMiddleware(patient);

      res.cookie("token", token);
      req.session.patient = {
        patient_id: patient.patient_id,
        email: patient.email,
      };
      var newPatient = {
        patient_id: patient.patient_id,
        first_name: patient.first_name,
        last_name: patient.last_name,
        email: patient.email,
        status: patient.status,
        notification: patient.notification,
        study_enrolled: patient.study_enrolled,
        stipend: patient.stipend,
        data_of_birth: patient.data_of_birth,
        contact_number: patient.contact_number,
        address: patient.address,
        gender: patient.gender,
        note: patient.note,
      };
      return res.status(201).json({
        status: true,
        message: "Patient Signin Successfully",
        patient: newPatient,
        token: token,
      });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ status: false, message: "Internal Server Error", error: error });
  }
};

// get all patients
var getAllPatients = async function (req, res) {
  try {
    var patients = await patientModel.getAllPatients();
    res
      .status(200)
      .json({ status: true, message: "All Patients", patients: patients });
  } catch (error) {
    res
      .status(500)
      .json({ status: false, message: "Internal Server Error", error: error });
  }
};

// get patient by id
var getPatientById = async function (req, res) {
  var patient_id = req.params.id;
  try {
    var patient = await patientModel.getPatientById(patient_id);
    res
      .status(200)
      .json({ status: true, message: "Patient", patient: patient });
  } catch (error) {
    res
      .status(500)
      .json({ status: false, message: "Internal Server Error", error: error });
  }
};

// update patient
var updatePatient = async function (req, res) {
  var patient_id = req.params.id;

  var _req$body2 = req.body,
    first_name = _req$body2.first_name,
    last_name = _req$body2.last_name,
    email = _req$body2.email,
    password = _req$body2.password,
    status = _req$body2.status,
    gender = _req$body2.gender,
    address = _req$body2.address,
    contact_number = _req$body2.contact_number,
    data_of_birth = _req$body2.data_of_birth,
    stipend = _req$body2.stipend,
    study_enrolled = _req$body2.study_enrolled,
    notification = _req$body2.notification;

  var hashPassword = crypto.SHA256(password).toString();
  try {
    var patient = await patientModel.updatePatient(
      patient_id,
      first_name,
      last_name,
      email,
      hashPassword,
      status,
      gender,
      address,
      contact_number,
      data_of_birth,
      stipend,
      study_enrolled,
      notification
    );
    res.status(200).json({
      status: true,
      message: "Patient Updated Successfully",
      patient: patient,
    });
  } catch (error) {
    res
      .status(500)
      .json({ status: false, message: "Internal Server Error", error: error });
  }
};

// delete patient
var deletePatient = async function (req, res) {
  var patient_id = req.params.id;
  try {
    var result = await patientModel.deletePatient(patient_id);
    res
      .status(200)
      .json({ status: true, message: "Patient Deleted Successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ status: false, message: "Internal Server Error", error: error });
  }
};

module.exports = {
  createPatient: createPatient,
  signinPatient: signinPatient,
  getAllPatients: getAllPatients,
  getPatientById: getPatientById,
  updatePatient: updatePatient,
  deletePatient: deletePatient,
};
