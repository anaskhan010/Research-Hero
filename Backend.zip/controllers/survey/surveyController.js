var surveyModel = require("../../models/survey/surveyModel.js");

// create survey controller
var createSurvey = async function (req, res) {
  var survey_title = req.body.survey_title;
  var question_text = req.body.question_text;

  try {
    var result = await surveyModel.createSurvey(survey_title, question_text);
    res
      .status(201)
      .json({ message: "Survey created successfully", survey: result });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal Server Error", error: error.message });
  }
};

module.exports = {
  createSurvey: createSurvey,
};
