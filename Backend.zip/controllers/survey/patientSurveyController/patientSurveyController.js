const patientSurveyModel = require("../../../models/survey/patientSurveyModel/patientSurveyModel");

// create patientSurveyController
const createPatientSurveyController = async (req, res) => {
  const {
    drug_name,
    date,
    drug_size,
    drug_dosage,
    drug_percentage,
    drug_quantity,
    patient_id,
  } = req.body;
  console.log("drug_name", drug_name);
  try {
    const result = await patientSurveyModel.createPatientSurvey(
      drug_name,
      date,
      drug_size,
      drug_dosage,
      drug_percentage,
      drug_quantity,
      patient_id
    );
    res
      .status(200)
      .json({ message: "Patient survey created successfully", result });
  } catch (err) {
    res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = { createPatientSurveyController };
