const appUserModel = require("../../models/appUser/appUserModel");
const crypto = require("crypto");
const authMiddleware = require("../../middleware/authMiddleware");

// create app user controller
const createAppUser = async (req, res) => {
  const { full_name, email, password, address, phone_number } = req.body;
  const hashedPassword = crypto
    .createHash("sha256")
    .update(password)
    .digest("hex");
  try {
    const result = await appUserModel.createAppUser(
      full_name,
      email,
      hashedPassword,
      address,
      phone_number
    );
    const newPatient = {
      full_name,
      email,
      address,
      phone_number,
    };
    res
      .status(200)
      .json({ message: "User Created Successfully", result: newPatient });
  } catch (err) {
    res.status(500).json(err);
  }
};

// login app user controller
const loginAppUser = async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await appUserModel.loginAppUser(email);

    if (!result) {
      return res.status(400).json({ message: "User not found" });
    }

    console.log("result", result);
    console.log("password", password);

    const hashedPassword = crypto
      .createHash("sha256")
      .update(password)
      .digest("hex");
    console.log("hashedPassword", hashedPassword);
    if (result.password !== hashedPassword) {
      return res.status(400).json({ message: "Invalid password" });
    } else {
      console.log("controller result", result);
      var token = authMiddleware.appUserToken(result);
      console.log("token", token);

      res.status(200).json({
        message: "Login Successfully",
        result: result,
        token: token,
      });
    }
  } catch (error) {
    res.status(500).json(error);
  }
};

module.exports = {
  createAppUser,
  loginAppUser,
};
