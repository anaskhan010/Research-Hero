var jwt = require("jsonwebtoken");
const authMiddleware = (patient) => {
  const token = jwt.sign(
    { patient_id: patient.patient_id, email: patient.email },
    "HJSDHDSLDLSDJSL",
    { expiresIn: "1h" }
  );

  return token;
};

const appUserToken = (appUser) => {
  const token = jwt.sign(
    { app_user_id: appUser.app_user_id, email: appUser.email },
    "HJSDHDSLDLSDJSL",
    { expiresIn: "1h" }
  );

  return token;
};

module.exports = { authMiddleware, appUserToken };
