var express = require("express");
var patientController = require("../../controllers/patient/patientController.js");

var router = express.Router();

router.post("/signin", patientController.signinPatient);

module.exports = router;
