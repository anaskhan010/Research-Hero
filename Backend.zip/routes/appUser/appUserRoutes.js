const express = require("express");
const router = express.Router();

const appUserController = require("../../controllers/appUser/appUserController");

router.post("/signup", appUserController.createAppUser);
router.post("/loginUser", appUserController.loginAppUser);

module.exports = router;
