var express = require("express");
var patientController = require("../../controllers/patient/patientController.js");

var router = express.Router();

router.post("/createPatient", patientController.createPatient);
router.get("/getAllPatients", patientController.getAllPatients);
router.get("/getPatientById/:id", patientController.getPatientById);
router.put("/updatePatient/:id", patientController.updatePatient);
router.delete("/deletePatient/:id", patientController.deletePatient);

module.exports = router;
