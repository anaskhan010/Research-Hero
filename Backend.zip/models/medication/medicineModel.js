var db = require("../../config/DBConnection.js");

// create medicine model
var createMedicine = function (
  medication_name,
  dosage,
  frequency,
  note,
  patient_id
) {
  return new Promise(function (resolve, reject) {
    var query =
      "INSERT INTO patientmedications (medication_name, dosage, frequency, note ,patient_id) VALUES (?,?,?,?,?)";
    db.query(
      query,
      [medication_name, dosage, frequency, note, patient_id],
      function (error, result) {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      }
    );
  });
};

// get All medication
var getAllMedication = function () {
  return new Promise(function (resolve, reject) {
    var query =
      "SELECT m.medication_id,p.patient_id, m.medication_name, m.dosage, m.frequency, p.study_enrolled,m.note, p.status FROM patientmedications AS m JOIN patient AS p ON m.patient_id = p.patient_id ";
    db.query(query, function (error, result) {
      if (error) {
        reject(error);
      } else {
        resolve(result);
      }
    });
  });
};

// get All medication by id
var getMedicationById = function (id) {
  return new Promise(function (resolve, reject) {
    var query =
      "SELECT m.medication_id,p.patient_id, m.medication_name, m.dosage, m.frequency, p.study_enrolled, p.status, n.note FROM patientmedications AS m JOIN patient AS p ON m.patient_id = p.patient_id JOIN note AS n ON m.note_id = n.note_id WHERE m.patient_id = ?";
    db.query(query, [id], function (error, result) {
      if (error) {
        reject(error);
      } else {
        resolve(result);
      }
    });
  });
};

// update medication
var updateMedication = function (id, medication_name, dosage, frequency, note) {
  console.log(
    "----------------------medicatin data for update--------------------- ",
    id,
    medication_name,
    dosage,
    frequency,
    note
  );
  return new Promise(function (resolve, reject) {
    var query =
      "UPDATE patientmedications SET medication_name = ?, dosage = ?, frequency = ? , note=?  WHERE medication_id = ?";
    db.query(
      query,
      [medication_name, dosage, frequency, note, id],
      function (error, result) {
        if (error) {
          reject(error);
        } else {
          console.log(result, "result");
          resolve(result);
        }
      }
    );
  });
};

// delete medication
var deleteMedication = function (id) {
  return new Promise(function (resolve, reject) {
    var query = "DELETE FROM patientmedications WHERE medication_id = ?";
    db.query(query, [id], function (error, result) {
      if (error) {
        reject(error);
      } else {
        resolve(result);
      }
    });
  });
};

module.exports = {
  createMedicine: createMedicine,
  getAllMedication: getAllMedication,
  getMedicationById: getMedicationById,
  updateMedication: updateMedication,
  deleteMedication: deleteMedication,
};
