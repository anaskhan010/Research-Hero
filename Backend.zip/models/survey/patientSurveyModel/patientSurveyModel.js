const db = require("../../../config/DBConnection");

// create patientSurveyModel
const createPatientSurvey = (
  drug_name,
  date,
  drug_size,
  drug_dosage,
  drug_percentage,
  drug_quantity,
  patient_id
) => {
  return new Promise((resolve, reject) => {
    const query = `INSERT INTO app_survey(drug_name,date,drug_size,drug_dosage,drug_percentage,drug_quantity,patient_id) VALUES(?,?,?,?,?,?,?)`;
    const value = [
      drug_name,
      date,
      drug_size,
      drug_dosage,
      drug_percentage,
      drug_quantity,
      patient_id,
    ];
    db.query(query, value, (err, result) => {
      if (err) {
        reject(err);
      }
      resolve(result);
    });
  });
};

module.exports = { createPatientSurvey };
