var db = require("../../config/DBConnection.js");

var createSurvey = function (
  survey_id,
  patient_id,
  question_id,
  response_text
) {
  return new Promise(function (resolve, reject) {
    var query =
      "INSERT INTO survey_response (survey_id, patient_id, question_id, response_text) VALUES (?, ?, ?, ?)";
    db.query(
      query,
      [survey_id, patient_id, question_id, response_text],
      function (error, result) {
        if (error) {
          reject(error);
        }
        resolve(result);
      }
    );
  });
};

var getAllSurveyResponses = function () {
  return new Promise(function (resolve, reject) {
    var query =
      "SELECT res.response_text , p.email, sur.survey_title ,sur.survey_id, q.question_text from survey_response as res JOIN patient as p ON res.patient_id = p.patient_id JOIN survey as sur ON res.survey_id = sur.survey_id JOIN survey_question as q ON res.question_id = q.question_id";
    db.query(query, function (error, result) {
      if (error) {
        reject(error);
      }
      resolve(result);
    });
  });
};

module.exports = {
  createSurvey: createSurvey,
  getAllSurveyResponses: getAllSurveyResponses,
};
