var db = require("../../config/DBConnection.js");

var createSurvey = function (survey_title, question_text) {
  return new Promise(function (resolve, reject) {
    db.beginTransaction(function (error) {
      if (error) {
        reject(error);
      }

      var surveyQuery = "INSERT INTO survey (survey_title) VALUES (?)";
      db.query(surveyQuery, [survey_title], function (error, surveyResult) {
        if (error) {
          db.rollback(function () {
            reject(error);
          });
        }

        var surveyId = surveyResult.insertId;
        var questionValues = question_text.map(function (question) {
          return [surveyId, question];
        });

        var questionQuery =
          "INSERT INTO survey_question (survey_id, question_text) VALUES ?";
        db.query(
          questionQuery,
          [questionValues],
          function (error, questionResult) {
            if (error) {
              db.rollback(function () {
                reject(error);
              });
            }

            db.commit(function (error) {
              if (error) {
                db.rollback(function () {
                  reject(error);
                });
              }

              resolve(questionResult);
            });
          }
        );
      });
    });
  });
};

module.exports = {
  createSurvey: createSurvey,
};
