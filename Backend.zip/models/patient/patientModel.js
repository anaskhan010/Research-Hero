var db = require("../../config/DBConnection.js");

// create patient
var createPatient = function (
  first_name,
  last_name,
  email,
  hashPassword,
  status,
  gender,
  address,
  contact_number,
  data_of_birth,
  stipend,
  study_enrolled,
  notification,
  note
) {
  return new Promise(function (resolve, reject) {
    db.beginTransaction(function (err) {
      if (err) {
        reject(err);
      }

      var query =
        "INSERT INTO patient (first_name, last_name, email, password, status, gender, address, contact_number, date_of_birth, stipend, study_enrolled, notification) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
      db.query(
        query,
        [
          first_name,
          last_name,
          email,
          hashPassword,
          status,
          gender,
          address,
          contact_number,
          data_of_birth,
          stipend,
          study_enrolled,
          notification,
        ],
        function (err, result) {
          if (err) {
            return db.rollback(function () {
              reject(err);
            });
          }

          var patientId = result.insertId;

          var noteQuery = "INSERT INTO Note (patient_id, note) VALUES (?, ?)";
          db.query(
            noteQuery,
            [patientId, note],
            function (noteErr, noteResult) {
              if (noteErr) {
                return db.rollback(function () {
                  reject(noteErr);
                });
              }

              db.commit(function (commitErr) {
                if (commitErr) {
                  return db.rollback(function () {
                    reject(commitErr);
                  });
                }

                resolve(result); // Resolve with the result of the insertion query
              });
            }
          );
        }
      );
    });
  });
};

// signin patient
var signinPatient = function (email) {
  console.log("Model email", email);
  return new Promise(function (resolve, reject) {
    var query = "SELECT * FROM patient WHERE email = ?";
    db.query(query, [email], function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result[0]);
      }
    });
  });
};

// get all patients
var getAllPatients = function () {
  return new Promise(function (resolve, reject) {
    var query = `SELECT p.*, MAX(n.note) AS note 
      FROM patient AS p 
      JOIN note AS n ON p.patient_id = n.patient_id 
      GROUP BY p.patient_id`;
    db.query(query, function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

// get patient by id
var getPatientById = function (patient_id) {
  return new Promise(function (resolve, reject) {
    var query = "SELECT * FROM patient WHERE patient_id = ?";
    db.query(query, [patient_id], function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result[0]);
      }
    });
  });
};

// update patient
var updatePatient = function (
  patient_id,
  first_name,
  last_name,
  email,
  hashPassword,
  status,
  gender,
  address,
  contact_number,
  data_of_birth,
  stipend,
  study_enrolled,
  notification
) {
  console.log(
    "model",
    patient_id,
    first_name,
    last_name,
    email,
    hashPassword,
    status,
    gender,
    address,
    contact_number,
    data_of_birth,
    stipend,
    study_enrolled,
    notification
  );
  return new Promise(function (resolve, reject) {
    var query =
      "UPDATE patient SET first_name = ?, last_name = ?, email = ?, password = ?, status = ?, gender = ?, address = ?, contact_number = ?, date_of_birth = ?, stipend = ?, study_enrolled = ?, notification = ? WHERE patient_id = ?";
    db.query(
      query,
      [
        first_name,
        last_name,
        email,
        hashPassword,
        status,
        gender,
        address,
        contact_number,
        data_of_birth,
        stipend,
        study_enrolled,
        notification,
        patient_id,
      ],
      function (err, result) {
        if (err) {
          reject(err);
        } else {
          var selectQuery = "SELECT * FROM patient WHERE patient_id = ?";
          db.query(selectQuery, [patient_id], function (error, rows) {
            if (error) {
              reject(error);
            } else {
              console.log("model row", rows[0]);
              resolve(rows[0]);
            }
          });
        }
      }
    );
  });
};

// delete patient
var deletePatient = function (patient_id) {
  return new Promise(function (resolve, reject) {
    var query = "DELETE FROM patient WHERE patient_id = ?";
    db.query(query, [patient_id], function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

module.exports = {
  createPatient: createPatient,
  signinPatient: signinPatient,
  getAllPatients: getAllPatients,
  getPatientById: getPatientById,
  updatePatient: updatePatient,
  deletePatient: deletePatient,
};
