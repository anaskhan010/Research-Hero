const db = require("../../config/DBConnection");

// create app user model
const createAppUser = (
  full_name,
  email,
  hashedPassword,
  address,
  phone_number
) => {
  return new Promise((resolve, reject) => {
    const query = `INSERT INTO app_user (full_name, email, password, address, phone_number) VALUES (?, ?, ?, ?, ?)`;
    const value = [full_name, email, hashedPassword, address, phone_number];
    db.query(query, value, (err, result) => {
      if (err) {
        reject(err);
      }
      console.log("result", result);
      resolve(result);
    });
  });
};

// login app user model
const loginAppUser = (email) => {
  return new Promise(function (resolve, reject) {
    var query = "SELECT * FROM app_user WHERE email = ?";
    db.query(query, [email], function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result[0]);
      }
    });
  });
};
module.exports = {
  createAppUser,
  loginAppUser,
};
