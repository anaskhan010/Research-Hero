var db = require("../../config/DBConnection.js");

var createSchedule = function (
  schedule_date,
  schedule_time,
  status,
  patient_id,
  note
) {
  return new Promise(function (resolve, reject) {
    db.beginTransaction(function (err) {
      if (err) {
        reject(err);
      } else {
        var noteQuery = "INSERT INTO note (patient_id, note) VALUES (?, ?)";
        db.query(noteQuery, [patient_id, note], function (noteErr, noteResult) {
          if (noteErr) {
            return db.rollback(function () {
              reject(noteErr);
            });
          }

          var scheduleQuery =
            "INSERT INTO schedule (schedule_date, schedule_time, status, patient_id) VALUES ( ?, ?, ?, ?)";
          db.query(
            scheduleQuery,
            [
              schedule_date,
              schedule_time,
              status,
              patient_id,
              noteResult.insertId,
            ],
            function (scheduleErr, scheduleResult) {
              if (scheduleErr) {
                return db.rollback(function () {
                  reject(scheduleErr);
                });
              }

              db.commit(function (commitErr) {
                if (commitErr) {
                  return db.rollback(function () {
                    reject(commitErr);
                  });
                }

                var selectQuery =
                  "SELECT * FROM schedule WHERE schedule_id = ?";
                db.query(
                  selectQuery,
                  [scheduleResult.insertId],
                  function (error, rows) {
                    if (error) {
                      reject(error);
                    } else {
                      console.log("model row", rows[0]);
                      resolve(rows[0]);
                    }
                  }
                );
              });
            }
          );
        });
      }
    });
  });
};
var getAllSchedules = function () {
  return new Promise(function (resolve, reject) {
    var query = `SELECT s.*, p.first_name, p.last_name, p.email, p.gender, p.status AS patient_status, MAX(n.note) AS note FROM schedule AS s 
      JOIN patient AS p ON s.patient_id = p.patient_id
      LEFT JOIN note AS n ON s.patient_id = n.patient_id
      GROUP BY s.schedule_id`;
    db.query(query, function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

var getScheduleById = function (schedule_id) {
  return new Promise(function (resolve, reject) {
    var query =
      "SELECT s.schedule_id, s.schedule_date, s.schedule_time, s.status AS schedule_status, p.first_name, p.last_name, p.gender, p.address, p.stipend, p.study_enrolled, n.note FROM schedule AS s JOIN patient AS p ON s.patient_id = p.patient_id JOIN note AS n ON s.note_id = n.note_id WHERE s.schedule_id = ?";
    db.query(query, [schedule_id], function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

var updateSchedule = function (
  schedule_id,
  schedule_date,
  schedule_time,
  status,
  note,
  patient_id
) {
  return new Promise(function (resolve, reject) {
    var updateNoteQuery = "UPDATE note SET note = ? WHERE patient_id = ?";
    db.query(updateNoteQuery, [note, patient_id], function (err, noteResult) {
      if (err) {
        reject(err);
      } else {
        var updateScheduleQuery =
          "UPDATE schedule SET schedule_date = ?, schedule_time = ?, status = ? WHERE schedule_id = ?";
        db.query(
          updateScheduleQuery,
          [schedule_date, schedule_time, status, schedule_id],
          function (err, scheduleResult) {
            if (err) {
              reject(err);
            } else {
              resolve(scheduleResult);
            }
          }
        );
      }
    });
  });
};

var deleteSchedule = function (schedule_id) {
  return new Promise(function (resolve, reject) {
    var query = "DELETE FROM schedule WHERE schedule_id = ?";
    db.query(query, [schedule_id], function (err, result) {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
};

module.exports = {
  createSchedule: createSchedule,
  getAllSchedules: getAllSchedules,
  getScheduleById: getScheduleById,
  updateSchedule: updateSchedule,
  deleteSchedule: deleteSchedule,
};
